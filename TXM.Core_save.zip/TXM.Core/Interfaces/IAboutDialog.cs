﻿namespace TXM.Core
{
    public interface IAboutDialog
    {
        void SetText(string text);
        void ShowDialog();
    }
}
