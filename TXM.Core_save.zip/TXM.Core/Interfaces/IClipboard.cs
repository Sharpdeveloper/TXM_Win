﻿namespace TXM.Core
{
    public interface IClipboard
    {
        void SetText(string text);
    }
}
